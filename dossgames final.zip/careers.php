<?php include_once('header.php') ?>
<div class="hiring-main-section">
    <div class="doss-banner-section hiring">
        <div class="container">
            <div class="row my_row">
                <div class="col l12 m12">
                    <div class="banner-heading">
                        Let's bring Blockchain gaming to the
                    </div>
                    <div class="banner-image center wow fadeInRight" data-wow-delay="0.2s">
                        <img src="images/hiring/main-stream-logo.png">
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="your-journey-section">
        <div class="container-fluid">
            <div class="row">
                <div class="interoperable-text center">
                    Your Journey in Doss
                </div>
                <div class="doss-desc center">
                    Ever wondered how it would be, to work in a start-up that is geared toward greatness? That too, a
                    blockchain gaming start-up?
                    At Doss Games, you get exactly that and more.
                </div>
                <div class="journey-points-section">
                    <div class="journey-points">
                        <div class="journey-image">
                            <img src="images/hiring/get-attracive-icon.png">
                        </div>
                        <div class="journey-desc">
                            Get attractive salaries, stock options, and full ownership at Doss!
                        </div>
                    </div>
                    <div class="journey-points">
                        <div class="journey-image">
                            <img src="images/hiring/we-will-reach-icon.png">
                        </div>
                        <div class="journey-desc">
                            We will teach you entrepreneurship, leadership, culture building, long-term vision strategy,
                            how to handle failures,
                            and everything you need to shape your career like a Boss. Trust, we have built these
                            multiple times in our careers.
                        </div>
                    </div>
                    <div class="journey-points">
                        <div class="journey-image">
                            <img src="images/hiring/here-icon.png">
                        </div>
                        <div class="journey-desc">
                            Here, you aren’t just employees - you are leaders! Doss Games is driven entirely by its
                            developers, and we put you
                            at the front and center of every decision we make!
                        </div>
                    </div>
                    <div class="journey-points">
                        <div class="journey-image">
                            <img src="images/hiring/we-also-icon.png">
                        </div>
                        <div class="journey-desc">
                            We also encourage you to take your entrepreneurial ideas to the world. Start out on your own
                            right from Day 1 at Doss,
                            and be a part of a network of investors from Harward, the IITs, IIMs, Stanford, and more!
                            Check out our Doss internal
                            funds for aspiring founders <u><a target="_blank"
                                    href="https://mukulsharma.info/">https://mukulsharma.info/</a></u>
                        </div>
                    </div>
                    <div class="journey-points">
                        <div class="journey-image">
                            <img src="images/hiring/you-get-icon.png">
                        </div>
                        <div class="journey-desc">
                            You get everything to help you excel at Doss - including Macbooks/laptops. We don't mind if
                            you bring your own
                            gaming consoles (PS5 or Xbox X, no judgments here!)
                        </div>
                    </div>
                    <div class="journey-points">
                        <div class="journey-image">
                            <img src="images/hiring/work-inhealthy-icon.png">
                        </div>
                        <div class="journey-desc">
                            Work in a healthy community of like-minded blockchain enthusiasts - no corporate politics,
                            only growth.
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="lifeat-doss-section">
        <div class="container-fluid">
            <div class="interoperable-text center">
                Life at Doss
            </div>
            <div class="row my_row">
                <div class="col l6 m12">
                    <div class="banner-image center wow fadeInLeft" data-wow-delay="0.2s">
                        <img src="images/hiring/life-at-doss-images.png">
                    </div>
                </div>
                <div class="col l6 m12">
                    <div class="lifeatdoss-desc">
                        <p>
                            Tired of corporate drudgery? Do you feel like your talents are better suited at a place that
                            values creative problem-solving, open communication, and game-changing endeavors?
                        </p>
                        <p>
                            Then, <strong>you’ll be right at home at Doss!</strong> Imbibe the cool factor of working at
                            a start-up - and mainly, a blockchain gaming startup! Be a part of the next big thing in the
                            gaming industry!
                        </p>
                        <p>
                            And, do you want to be a part of the next thing in gaming technology?
                        </p>
                    </div>
                </div>
            </div>
            <div class="photo-gallery-section">
                <div class="photo-gallery-two">
                    <div class="photo-gallery">
                        <img src="images/hiring/gallary1.jpg">
                    </div>
                    <div class="photo-gallery">
                        <img src="images/hiring/gallary2.jpg">
                    </div>
                </div>
                <div class="photo-gallery-two">
                    <div class="photo-gallery">
                        <img src="images/hiring/gallary3.jpg">
                    </div>
                    <div class="photo-gallery">
                        <img src="images/hiring/gallary4.jpg">
                    </div>
                </div>
                <div class="photo-gallery-two">
                    <div class="photo-gallery">
                        <img src="images/hiring/gallary5.jpg">
                    </div>
                    <div class="photo-gallery">
                        <img src="images/hiring/gallary6.jpg">
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="open-position-section">
        <div class="container-fluid">
            <div class="interoperable-text center">
                Open Positions
            </div>
            <div class="opening-positions-main">
                <a href="https://tanmay-joshi.notion.site/Product-Manager-1ff773c3d3a4408281476807dfd23572"
                    target="_blank" class="open-position">
                    <div class="open=image">
                        <img src="images/hiring/product-manager-icon.png">
                    </div>
                    <div class="open-position-name">
                        Product Manager
                    </div>
                </a>
                <a href="https://tanmay-joshi.notion.site/Blockchain-Developer-44b60d47e245496382a223b04a081d7a"
                    target="_blank" class="open-position">
                    <div class="open=image">
                        <img src="images/hiring/blockchain-icon.png">
                    </div>
                    <div class="open-position-name">
                        Blockchain Developer
                    </div>
                </a>
                <a href="https://tanmay-joshi.notion.site/Lead-Game-Developer-708c6a7829cc4df4af9bfb7c1d9b10ce"
                    target="_blank" class="open-position">
                    <div class="open=image">
                        <img src="images/hiring/game-dev-icon.png">
                    </div>
                    <div class="open-position-name">
                        Game Developer
                    </div>
                </a>
                <a href="https://tanmay-joshi.notion.site/Lead-Game-Designer-b6189613cbc44dd1ab177a57784fb116"
                    target="_blank" class="open-position">
                    <div class="open=image">
                        <img src="images/hiring/game-designer-icon.png">
                    </div>
                    <div class="open-position-name">
                        Game Designer
                    </div>
                </a>
                <a href="https://tanmay-joshi.notion.site/3D-game-artist-725487b8408f47c890004daee54418c9"
                    target="_blank" class="open-position">
                    <div class="open=image">
                        <img src="images/hiring/3d-icon.png">
                    </div>
                    <div class="open-position-name">
                        3D Game Artist
                    </div>
                </a>
            </div>
            <div class="write-us-section">
                <div class="writeus-heading">
                    Didn’t find a suitable position?
                </div>
                <div class="doss-desc">
                    Write to us, at <u><a href="mailto:careers@doss.games">careers(at)doss.games</a></u>, and we will
                    get
                    back to you!
                </div>
            </div>
        </div>
    </div>
    <?php include_once('footer.php') ?>
</div>