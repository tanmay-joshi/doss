<?php include_once('header.php') ?>
<div class="players-main-section">
    <div class="doss-banner-section player">
        <div class="container">
            <div class="row my_row">
                <div class="col l6 m12">
                    <div class="banner-image wow fadeInRight" data-wow-delay="0.2s">
                        <img src="images/player/bringing-gamingto-image.png" class="hide-on-med-and-down">
                        <img src="images/player/bringing-gamingto-image1.png" class="hide-on-large-only">
                    </div>
                    <div class="banner-text">
                        Web3
                    </div>

                    <div class="doss-btn-section">
                        <!-- <a href="contact-us.php" class="doss-btn small">Join Us</a>  -->
                        <a href="https://play.google.com/store/apps/details?id=com.Dossgames.Doss" target="_blank"><img
                                src="images/player/google-play-icon.png" /></a>
                    </div>
                </div>
                <div class="col l6 m12">
                    <div class="banner-image wow zoomIn" data-wow-delay="0.4s">
                        <img src="images/player/player-banner-image.png">
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="blockchain-game-section">
        <div class="container-fluid">
            <div class="interoperable-text center">
                Blockchain games: for the community, by the community!
            </div>
            <div class="bgame-main-grid">
                <div class="row my_row">
                    <div class="col l4 m6 s12">
                        <div class="blockchain-game-ind">
                            <div class="blockchain-game-image wow fadeIn" data-wow-delay="0.3s">
                                <img src="images/player/last-stand-image.jpg">
                            </div>
                            <div class="blockchain-content">
                                <div class="bgame-tag">FPS Survival Shooter</div>
                                <div class="bgame-name">Last Stand</div>
                                <div class="bgame-desc">"An intense FPS Survival Shooter game where you play as a
                                    Special Ops Soldier who has been let off the hook by the agency. An entire army of
                                    Elite units is coming for you. They want you eliminated. Fight to survive the
                                    oncoming waves of hostile soldiers. Use your environment well to your advantage. The
                                    enemy is all around you. Your weapons are all you got.
                                    Your Last Stand !"
                                </div>
                                <div class="doss-btn-section">
                                    <a href="https://play.google.com/store/apps/details?id=com.Dossgames.Doss"
                                        target="_blank"><img src="images/player/google-play-icon.png" /></a>
                                </div>
                                <div class="bgame-token">
                                    <img src="images/player/token-icon.png">
                                    <div>Prize pool: 10,000 Doss tokens</div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col l4 m6 s12">
                        <div class="blockchain-game-ind">
                            <div class="blockchain-game-image wow fadeIn" data-wow-delay="0.4s">
                                <img src="images/player/bomb-run-image.jpg">
                            </div>
                            <div class="blockchain-content">
                                <div class="bgame-tag">Arcade Driving Simulator</div>
                                <div class="bgame-name">Bomb Run</div>
                                <div class="bgame-desc">"An action Arcade Driving Simulator. Your car has been rigged
                                    with Explosives by the Rival Gang. Keep it moving. You stop, you go KAABOOOM ! Keep
                                    driving and keep it moving. Drift, turn, brake and evade to survive as long as you
                                    can, in this Action Arcade Driving experience. A vast city to explore and speed
                                    through.
                                    Buckle-up and floor it ! "
                                </div>
                                <div class="doss-btn-section">
                                    <a href="https://play.google.com/store/apps/details?id=com.Dossgames.Doss"
                                        target="_blank"><img src="images/player/google-play-icon.png" /></a>
                                </div>
                                <div class="bgame-token">
                                    <img src="images/player/token-icon.png">
                                    <div>Prize pool: 10,000 Doss tokens</div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col l4 m6 s12">
                        <div class="blockchain-game-ind">
                            <div class="blockchain-game-image wow fadeIn" data-wow-delay="0.5s">
                                <img src="images/player/wanted-image.jpg">
                            </div>
                            <div class="blockchain-content">
                                <div class="bgame-tag">Cop Chase Driving Simulator</div>
                                <div class="bgame-name">Wanted - ( COMING SOON )</div>
                                <div class="bgame-desc">An isometric Cop Chase Simulator where you play as a WANTED
                                    fugitive on the run. The cops are all over you. A GRAND high-speed chase is about to
                                    go down. Cop cars coming at you from all directions. Push those driving skills over
                                    the limits. Quick turns and diversions to have them collide into each other. Drive
                                    through the forests, drive through deserted ruins. Circle around the mountains and
                                    zig zag through ancient lands. No matter what happens, do not let them catch you !
                                </div>
                                <div class="doss-btn-section">
                                    <a href="https://play.google.com/store/apps/details?id=com.Dossgames.Doss"
                                        target="_blank"><img src="images/player/google-play-icon.png" /></a>
                                </div>
                                <div class="bgame-token">
                                    <img src="images/player/token-icon.png">
                                    <div>Prize pool: 10,000 Doss tokens</div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="why-dossverse-section">
        <div class="container">
            <div class="interoperable-text center">
                Why Dossverse?
            </div>
            <div class="why-dossverse-main-grid">
                <div class="why-dossverse-grid">
                    <div class="whyd-content row">
                        <div class="col l5 s12">
                            <div class="whyd-image wow fadeInLeft" data-wow-delay="0.3s">
                                <img src="images/player/one-token-image.png">
                            </div>
                        </div>
                        <div class="col l7 s12">
                            <div class="whyd-content-section">
                                <div class="whyd-heading">
                                    One token, unlimited games
                                </div>
                                <div class="whyd-desc">
                                    Whether you’re here to earn crypto rewards, or to play for fun, Doss Games promises
                                    a
                                    unique
                                    and immersive gaming experience that is as exciting as it is rewarding!
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="why-dossverse-grid">
                    <div class="whyd-content row">
                        <div class="col l5 s12">
                            <div class="whyd-image wow fadeInLeft" data-wow-delay="0.4s">
                                <img src="images/player/3dmultiplayer-image.png">
                            </div>
                        </div>
                        <div class="col l7 s12">
                            <div class="whyd-content-section">
                                <div class="whyd-heading">
                                    3D multiplayer games
                                </div>
                                <div class="whyd-desc">
                                    Show off your competitive edge, climb up the leaderboards, and win fungible crypto
                                    rewards in real-time. Buy, sell, or carry - get ownership of real assets!
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
                <div class="why-dossverse-grid">
                    <div class="whyd-content row">
                        <div class="col l5 s12">
                            <div class="whyd-image wow fadeInLeft" data-wow-delay="0.5s">
                                <img src="images/player/stake-image.png">
                            </div>
                        </div>
                        <div class="col l7 s12">
                            <div class="whyd-content-section">
                                <div class="whyd-heading">
                                    Stake and win in blockchain
                                    tournaments
                                </div>
                                <div class="whyd-desc">
                                    Collect enough tokens, transfer them onto the next game you’re playing, and earn
                                    more
                                    such real-time benefits.
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="onewallet-section center">
        <div class="container-fluid">
            <div class="interoperable-text">
                One wallet, unlimted possibilities
            </div>
            <div class="doss-desc">
                With a single crypto gaming wallet, you can access all the blockchain games powered by Doss.
            </div>
            <div class="onewallet-image wow zoomIn" data-wow-delay="0.4s">
                <a><img src="images/player/one-wallet-image.png"></a>
            </div>
        </div>
    </div>

    <div class="footer-banner-section">
        <div class="container-fluid">
            <div class="row">
                <div class="col l6 m12">
                    <div class="footer-banner-content">
                        <div class="footer-banner-heading">
                            Plunge into the World of Blockchain Gaming
                        </div>
                        <div class="footer-join-us">
                            Join Us.
                        </div>
                        <div class="footer-btn">
                            <a href="players.php" class="doss-btn">
                                Start Playing
                            </a>
                        </div>
                    </div>
                </div>
                <div class="col l6 m12">
                    <div class="footer-image wow fadeInUp" data-wow-delay="0.4s">
                        <img src="images/player/footer-banner-image.png">
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php include_once('footer.php') ?>
</div>