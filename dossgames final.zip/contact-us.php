<?php include_once('header.php') ?>
<div class="contact-main-section">
    <div class="doss-banner-section contact">
        <div class="container">
            <div class="row my_row">
                <div class="col l6 m12">
                    <div class="banner-image wow fadeInRight" data-wow-delay="0.2s">
                        <img src="images/contactus/we-love-tohere.png">
                    </div>
                    <div class="banner-text">
                        Back from you!
                    </div>
                </div>
                <div class="col l6 m12">
                    <div class="banner-image wow fadeInRight" data-wow-delay="0.4s">
                        <img src="images/contactus/contact-us-banner-image.png">
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="location-section center">
        <div class="container">
            <div class="addresses-section">
                <div class="address-ind">
                    <div class="address-image">
                        <img src="images/contactus/headquarter-icon.png">
                    </div>
                    <div class="address-heading">
                        Headquarters
                    </div>
                    <div class="address-desc">
                        160 Robinson road, #20-03
                        Singapore, 068914
                    </div>
                </div>
                <div class="address-ind">
                    <div class="address-image">
                        <img src="images/contactus/india-office-icon.png">
                    </div>
                    <div class="address-heading">
                        India office
                    </div>
                    <div class="address-desc">
                        Ground Floor, Hustle hub tech park, #36/5, Somasandra Palya, Sector2, adjacent 27thMainRoad, HSR
                        Layout, Bengaluru, Karnataka 560102
                    </div>
                </div>
            </div>
            <div class="mail-section">
                <div class="mail-image">
                    <img src="images/contactus/mail-icon.png">
                </div>
                <div class="mail-content">
                    <div class="address-heading">
                        Write to Us
                    </div>
                    <div class="address-desc">
                        Email id: <a href="mailto:info@doss.games">info(at)doss.games</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php include_once('footer.php') ?>
</div>