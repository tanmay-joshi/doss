<!DOCTYPE html PUBLIC"-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html>

<head>
    <meta name="viewport"
        content="width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=no" />
    <meta http-equiv="content-type" content="text/html; charset=utf-8" />
    <link rel="icon" type="image/png" sizes="16x16" href="favicon.png">
    <?php include_once('content_analysis.php') ?>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@100;200;300;400;500;600;700;800;900&display=swap"
        rel="stylesheet">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet" />
    <script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link type="text/css" rel="stylesheet" href="css/materialize.css" media="screen,projection" />
    <link type="text/css" rel="stylesheet" href="css/animate.min.css" media="screen,projection" />
    <link type="text/css" rel="stylesheet" href="css/styles.css?<?= time() ?>" media="screen,projection" />
    <link type="text/css" rel="stylesheet" href="css/responsive.css?<?= time() ?>" media="screen,projection" />
</head>

<body>
    <div class="main-doss-wrapper">
        <header>
            <div class="row">
                <div class="header-flex">
                    <div class="col l4 my_row">
                        <div class="doss-menu">
                            <nav class="nav-extended">
                                <div class="nav-wrapper wow fadeIn" data-wow-delay="0.5s">
                                    <a href="#" data-target="mobile-demo" class="sidenav-trigger"><i
                                            class="material-icons">menu</i></a>
                                    <ul id="nav-mobile" class="hide-on-med-and-down">
                                        <li><a href="index.php">Home</a></li>
                                        <li><a href="players.php">Players</a></li>
                                        <li><a href="developers.php">Developers</a></li>
                                        <li><a href="about-us.php">About Us</a></li>
                                        <li><a href="careers.php">Careers</a></li>
                                        <li><a href="contact-us.php">Contact Us</a></li>
                                    </ul>
                                </div>
                            </nav>
                            <ul class="sidenav" id="mobile-demo">
                                <li><a href="index.php">Home</a></li>
                                <li><a href="players.php">Players</a></li>
                                <li><a href="developers.php">Developers</a></li>
                                <li><a href="about-us.php">About Us</a></li>
                                <li><a href="careers.php">Careers</a></li>
                                <li><a href="contact-us.php">Contact Us</a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col l4 my_row">
                        <div class="doss-logo  wow fadeIn" data-wow-delay="0.5s">
                            <?php

// Please DONT REMOVE the below Line


                            $page = $_SERVER["PHP_SELF"];
                            if ($page === "/doss/index.php") {   
                            ?>
                            <a href="/dossgames/"><img src="images/logo2.png"></a>
                            <?php } else if ($page != "/doss/index.php") { ?>
                            <a href="/dossgames/"><img src="images/logo2.png"></a>
                            <?php } ?>



                            <!-- <a href="/dossgames/"><img src="images/logo.png"></a> -->
                        </div>
                    </div>
                    <!-- <div class="col l4 my_row">
                        <div class="profile-section">
                            <img src="images/profile-icon.png" />
                            <a href="#" class="profile-text">Profile</a>
                        </div>
                    </div> -->
                </div>
            </div>
        </header>