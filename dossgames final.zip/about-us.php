<?php include_once('header.php') ?>
<div class="about-us-main-section">
    <div class="doss-banner-section aboutus">
        <div class="container">
            <div class="row my_row">
                <div class="col l6 m12">
                    <div class="banner-image wow fadeInRight" data-wow-delay="0.2s">
                        <img src="images/aboutus/gettoknow-image.png">
                    </div>
                </div>
                <div class="col l6 m12">
                    <div class="banner-image wow zoomIn" data-wow-delay="0.4s">
                        <img src="images/aboutus/about-banner-image.png">
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="who-we-are-section">
        <div class="container">
            <div class="interoperable-text center">
                Who we are
            </div>
            <div class="row my_row">
                <div class="col l6 m12">
                    <div class="who-we-are-image">
                        <img src="images/aboutus/www-image.png">
                    </div>
                </div>
                <div class="col l6 m12">
                    <div class="wwr-desc">
                        <p>
                            Doss Games is the brainchild of a bunch of product entrepreneurs, engineers, developers, and
                            designers from IIT Roorkee, united by their love for gaming, enthusiasm for everything
                            blockchain, and building amazing products.
                        </p>
                        <p>
                            A community for debonair designers, rockstar developers, and the most brilliant business
                            minds, Doss Games has but one purpose - redefining blockchain gaming.
                        </p>
                        <p>
                            We want to build the 1st of a kind truly decentralized gaming ecosystem where developers,
                            creators, artists, players, brands, and everyone will come, collaborate and create amazing
                            games on a chain in the Doss ecosystem. We believe that to build the next web3 gaming
                            company, someone has to enable the communities to come, play and build together and create
                            value for everyone fairly.
                        </p>
                        <p>
                            Backed by marquee investors from the Web3, blockchain, and GameFi communities across the
                            USA, UK, Israel, Singapore, and India, we are poised to push game development to the new
                            generation of the internet.
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="who-we-are-section">
        <div class="container-fluid">
            <div class="interoperable-text center">
                The Brains Behind Doss
            </div>
            <div class="brains-main-grid">
                <div class="brains-grid">
                    <div class="brain-image"> <img src="images/aboutus/mukulsharma.jpg"></div>
                    <div class="brain-name">Mukul Sharma</div>
                    <div class="brain-designation">Founder and CEO</div>
                    <div class="brain-social-links">
                        <a href="https://twitter.com/muks887"><i class="fab fa-twitter-square"></i></a>
                        <a href="https://www.linkedin.com/in/mukulsharma887/" target="_blank"><i
                                class="fab fa-linkedin"></i></a>
                    </div>
                </div>
                <div class="brains-grid">
                    <div class="brain-image"> <img src="images/aboutus/tanmayjoshi-image.jpg"></div>
                    <div class="brain-name">Tanmay Joshi</div>
                    <div class="brain-designation">Founder and CTO</div>
                    <div class="brain-social-links">
                        <a href="https://twitter.com/tanmay_who"><i class="fab fa-twitter-square"></i></a>
                        <a href="https://www.linkedin.com/in/tanmayjoshi96" target="_blank"><i
                                class="fab fa-linkedin"></i></a>
                    </div>
                </div>
                <div class="brains-grid">
                    <div class="brain-image"> <img src="images/aboutus/vishal.jpg"></div>
                    <div class="brain-name">Vishal Sharma</div>
                    <div class="brain-designation">Core team, Blockchain developer
                    </div>
                    <div class="brain-social-links">
                        <a href="#"><i class="fab fa-twitter-square"></i></a>
                        <a href="#"><i class="fab fa-linkedin"></i></a>
                    </div>
                </div>
                <div class="brains-grid">
                    <div class="brain-image"> <img src="images/aboutus/aniket-mathur.jpg"></div>
                    <div class="brain-name">Aniketh Mathur</div>
                    <div class="brain-designation">Core team, Blockchain developer
                    </div>
                    <div class="brain-social-links">
                        <a href="https://twitter.com/vishalol_"><i class="fab fa-twitter-square"></i></a>
                        <a href="https://www.linkedin.com/in/vishalcr7/"><i class="fab fa-linkedin"></i></a>
                    </div>
                </div>
                <div class="brains-grid">
                    <div class="brain-image"> <img src="images/aboutus/abhi.jpg"></div>
                    <div class="brain-name">Abhi Maruthu</div>
                    <div class="brain-designation">Lead game designer</div>
                    <div class="brain-social-links">
                        <!-- <a href="#"><i class="fab fa-twitter-square"></i></a> -->
                        <a href="https://www.linkedin.com/in/abhimaruthu/"><i class="fab fa-linkedin"></i></a>
                    </div>
                </div>
                <div class="brains-grid">
                    <div class="brain-image"> <img src="images/aboutus/rakshit.jpg"></div>
                    <div class="brain-name">Rakshit Thakur</div>
                    <div class="brain-designation">Unity game developer</div>
                    <div class="brain-social-links">
                        <!-- <a href="#"><i class="fab fa-twitter-square"></i></a> -->
                        <a href="https://www.linkedin.com/in/rakshit-thakur-80bb3076/"><i
                                class="fab fa-linkedin"></i></a>
                    </div>
                </div>
                <div class="brains-grid">
                    <div class="brain-image"> <img src="images/aboutus/nikil-aryaan.jpg"></div>
                    <div class="brain-name">Nikhil Arya</div>
                    <div class="brain-designation">Associate product manager
                    </div>
                    <div class="brain-social-links">
                        <!-- <a href="#"><i class="fab fa-twitter-square"></i></a> -->
                        <a href="https://www.linkedin.com/in/nikhil-arya/"><i class="fab fa-linkedin"></i></a>
                    </div>
                </div>
                <div class="brains-grid">
                    <div class="brain-image"> <img src="images/aboutus/azzad.jpg"></div>
                    <div class="brain-name">Azzad</div>
                    <div class="brain-designation">Game artist
                    </div>
                    <div class="brain-social-links">
                        <!-- <a href="#"><i class="fab fa-twitter-square"></i></a> -->
                        <a href="https://www.linkedin.com/in/azaad-chattar-a61477219/"><i
                                class="fab fa-linkedin"></i></a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="our-investor-section">
        <div class="container">
            <div class="interoperable-text center">
                Our Investors
            </div>
            <div class="doss-games2">
                Doss Games is supported by investments from:
            </div>
            <div class="doss-desc">
                World-class Global VCs who understand cryptography, blockchain, gaming, SaaS, consumer apps, and brand
                building to their depth.
            </div>
        </div>
    </div>
    <div class="our-investor-section">
        <div class="container-fluid">
            <div class="investors-locations">
                <div class="investor-location-ind">
                    <div class="investor-location-image">
                        <img src="images/aboutus/titan.png">
                    </div>
                    <div class="investor-location-name">
                        Titan Capital, India
                    </div>
                </div>
                <div class="investor-location-ind">
                    <div class="investor-location-image">
                        <img src="images/aboutus/somacapital.png">
                    </div>
                    <div class="investor-location-name">
                        Soma Capital, USA
                    </div>
                </div>
                <div class="investor-location-ind">
                    <div class="investor-location-image">
                        <img src="images/aboutus/geometry.png">
                    </div>
                    <div class="investor-location-name">
                        Geometry Dao, UK
                    </div>
                </div>
            </div>
            <div class="doss-games2">
                Selected angel investors who have been with us from day 0
            </div>
            <div class="investors-main-grid">
                <div class="investor-grid">
                    <div class="investor-image"> <img src="images/aboutus/kunal.jpg"></div>
                    <div class="brain-name">Kunal Bahl</div>
                    <div class="brain-designation">Founder, Snapdeal</div>
                </div>
                <div class="investor-grid">
                    <div class="investor-image"> <img src="images/aboutus/maninder.jpg"></div>
                    <div class="brain-name">Maninder Gulati</div>
                    <div class="brain-designation">Global chief strategy officer, Oyo</div>
                </div>
                <div class="investor-grid">
                    <div class="investor-image"> <img src="images/aboutus/abhinav-sinha.jpg"></div>
                    <div class="brain-name">Abhinav Sinha</div>
                    <div class="brain-designation">Chief operating officer, Oyo</div>
                </div>
                <div class="investor-grid">
                    <div class="investor-image"> <img src="images/aboutus/varun-alagh.jpg"></div>
                    <div class="brain-name">Varun Alag</div>
                    <div class="brain-designation">CEO, MamaEarth</div>
                </div>
            </div>
            <div class="doss-games2">
                and 30+ kickass backers
            </div>
        </div>
    </div>
    <div class="footer-banner-section">
        <div class="container-fluid">
            <div class="row">
                <div class="col l6 m12">
                    <div class="footer-banner-content">
                        <div class="footer-banner-heading">
                            Inspired by what we’re doing?
                            Be a Part of Doss!
                        </div>
                        <div class="footer-btn">
                            <a href="careers.php" class="doss-btn">
                                Explore Careers
                            </a>
                        </div>
                    </div>
                </div>
                <div class="col l6 m12">
                    <div class="footer-image">
                        <img src="images/aboutus/aboutus-footer-banner-image.png">
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php include_once('footer.php') ?>
</div>