<?php include_once('header.php') ?>
<div class="devoloper-main-section">
    <div class="doss-banner-section developer">
        <div class="container">
            <div class="row my_row">
                <div class="col l6 m12">
                    <div class="banner-image wow fadeInRight" data-wow-delay="0.2s">
                        <img src="images/developer/decentralization-logo.png">
                    </div>
                    <div class="banner-text">
                        of game creation
                    </div>
                    <div class="doss-banner-desc"> Empowering the creator communities to collaborate, build, and own in
                        the truly trustless ecosystem.
                    </div>
                    <div class="doss-btn small">
                        Build with Doss
                    </div>
                </div>
                <div class="col l6 m12">
                    <div class="banner-image wow zoomIn" data-wow-delay="0.4s">
                        <img src="images/developer/developer-banner-image.png">
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="weare-brecking-section">
        <div class="container-fluid">
            <div class="interoperable-text center">
                We are breaking the traditional way of creating games with our
            </div>
            <div class="decentralized-main-section">
                <div class="row decentralized-section">
                    <div class="col l5 m12 s12">
                        <div class="decent-image">
                            <img src="images/developer/decentralised-autonomos-image.png">
                        </div>
                    </div>
                    <div class="col l7 m12 s12">
                        <div class="decent-content">
                            <div class="decent-btn">
                                Ideate, iterate, and collaborate
                            </div>
                            <div class="decent-heading">
                                Decentralized Autonomous Gaming Studio
                            </div>
                            <div class="decent-desc">
                                Collaborate and build trustlessly. Safe way to collaborate with developers, designers,
                                artists
                                and game entrepreneurs to build games and share revenues of games, assets, designs
                                fairly.
                                Your
                                contributions are on smart contract, no one can manipulate it.
                            </div>
                            <!-- <div class="decent-btn-section">
                                <a href="#" class="doss-btn extra-small">
                                    Go to Doc's
                                </a>
                            </div> -->
                        </div>
                    </div>
                </div>
                <div class="row decentralized-section decent-game">
                    <div class="col l6 m12 s12">
                        <div class="decent-content">
                            <div class="decent-btn">
                                Design, develop, and build
                            </div>
                            <div class="decent-heading">
                                Decentralized Game Engine
                            </div>
                            <div class="decent-desc">
                                Use our powerful SDK’s and plugins integrated with Unity, Unreal Engine to build your
                                games
                                on blockchain. It's super easy and seamless.
                            </div>
                            <!-- <div class="decent-btn-section">
                                <a href="#" class="doss-btn extra-small">
                                    Go to Doc's
                                </a>
                            </div> -->
                        </div>
                    </div>
                    <div class="col l6 m12 s12">
                        <div class="decent-image">
                            <img src="images/developer/decentralised-game-image.png">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="decent-btn-section center">
        <a href="#" class="doss-btn extra-small">
            Read More
        </a>
    </div>
    <div class="how-it-work-section">
        <div class="container-fluid">
            <div class="interoperable-text center">
                How it Works
            </div>
            <div class="row my_row">
                <div class="col l3 m6 s12">
                    <div class="hiw-steps">
                        <div class="hiw-img">
                            <img src="images/developer/collabarate-icon.png">
                        </div>
                        <div class="hiw-heading">
                            Step 1: Collaborate
                        </div>
                        <div class="doss-desc">
                            Ideate with other creators, developers, managers and investors to start building the game
                            ideas.
                        </div>
                    </div>
                </div>
                <div class="col l3 m6 s12">
                    <div class="hiw-steps">
                        <div class="hiw-img">
                            <img src="images/developer/build-icon.png">
                        </div>
                        <div class="hiw-heading">
                            Step 2: Build
                        </div>
                        <div class="doss-desc">
                            Use our seamless SDK’s and plugins to build your games on blockchain. Trust us, it's super
                            easy and safe.
                        </div>
                    </div>
                </div>
                <div class="col l3 m6 s12">
                    <div class="hiw-steps">
                        <div class="hiw-img">
                            <img src="images/developer/publish-icon.png">
                        </div>
                        <div class="hiw-heading">
                            Step 3: Publish
                        </div>
                        <div class="doss-desc">
                            Start publishing your games on our gaming app in a single click.
                        </div>
                    </div>
                </div>
                <div class="col l3 m6 s12">
                    <div class="hiw-steps">
                        <div class="hiw-img">
                            <img src="images/developer/earn-icon.png">
                        </div>
                        <div class="hiw-heading">
                            Step 4: Earn fairly
                        </div>
                        <div class="doss-desc">
                            That's all, your game is live and every creator will earn fairly who has contributed to the
                            project.
                        </div>
                    </div>
                </div>
            </div>
            <div class="row my_row howit-section">
                <div class="col l6 m12 my_row">
                    <div class="interoparable-image">
                        <img src="images/developer/how-it-works-image.png" />
                    </div>
                </div>
                <div class="col l6 m12 my_row">
                    <div class="interoparable-content-section left-align">
                        <div class="interoperable-text">
                            How it Works
                        </div>
                        <div class="doss-desc">
                            <ul>
                                <li>Join and collaborate with a community of designers, developers, and gaming
                                    enthusiast</li>
                                <li>Track and improve your game’s performance through real-time analytics.
                                </li>
                                <li>Develop, launch, share and earn on a trustless platform</li>
                                <li>Watch your games thrive without relying on third parties! </li>
                                <li>Step into Web3, with ease! </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="footer-banner-section">
        <div class="container-fluid">
            <div class="row">
                <div class="col l6 m12">
                    <div class="footer-banner-content">
                        <div class="footer-banner-heading">
                            Launch your own Blockchain-powered Games.
                        </div>

                        <div class="footer-btn">
                            <a href="players.php" class="doss-btn">
                                Launch now
                            </a>
                        </div>
                    </div>
                </div>
                <div class="col l6 m12">
                    <div class="footer-image">
                        <img src="images/developer/developer-footer-banner-image.png">
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php include_once('footer.php') ?>
</div>