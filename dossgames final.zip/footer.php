<div class="clearfix"></div>
<footer>
    <div class="footer-main-section">
        <div class="container">
            <div class="row my_row">
                <div class="col l12 m12 my_row footer-left-section left-align">
                    <div class="col l3 m3 s6 my_row">
                        <div><img src="images/footer-logo.png"></div>
                    </div>
                    <div class="col l3 m3 s12 my_row">
                        <div class="footer-heading">Doss Ecosystem</div>
                        <ul class="footer-links">
                            <li><a href="players.php">Players</a></li>
                            <li><a href="developers.php">Developers</a></li>
                        </ul>
                    </div>
                    <div class="col l3 m3 s12 my_row">
                        <div class="footer-heading">General</div>
                        <ul class="footer-links">
                            <li><a href="about-us.php">About Us</a></li>
                            <li><a href="careers.php">Careers</a></li>
                        </ul>
                    </div>
                    <div class="col l3 m3 s12 my_row">
                        <div class="footer-heading">Support</div>
                        <ul class="footer-links">
                            <li><a href="contact-us.php">Contact Us</a></li>
                            <li><a href="terms-condition.php">Terms & Conditions</a></li>
                            <li><a href="privacy-policy.php">Privacy Policy</a></li>
                        </ul>
                    </div>
                </div>
                <div class="col l12 m12 s12 my_row">
                    <div class="footer-right-section">
                        <div class="footer-logo">
                            <div class="copy-right">Doss - © 2022 All Rights Reserved. | Branded by <a
                                    href="https://www.thegotoguy.co/" target="_blank">The Go-To Guy!</a></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</footer>
<script type="text/javascript" src="js/jquery.min.js"></script>
<script type="text/javascript" src="js/wow.min.js"></script>
<script type="text/javascript" src="js/materialize.js"></script>
<script type="text/javascript" src="js/global.js"></script>
</body>

</html>