<?php include_once('header.php') ?>
<div class="doss-body-wrapper homepage-wrapper">
    <div class="doss-banner-section homepage">
        <div class="container">
            <div class="row my_row">
                <div class="hp-banner-sec">
                    <div class="hp-heading wow fadeIn" data-wow-delay="0.3s">
                        Enter a whole new dimension of
                    </div>
                    <div class="banner-image">
                        <img src="images/internet-economies-image.png">
                    </div>
                    <div class="banner-image wow fadeInUp" data-wow-delay="0.5s">
                        <img src="images/4cubes-image.png">
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="dcp-section">
        <div class="container">
            <div class="row">
                <div class="banner-image wow fadeIn" data-wow-delay="0.5s">
                    <div class="setting-round">
                        <img class="rotate" src="images/inner-setting-image.png">
                    </div>
                </div>
                <div class="where-hp-text">
                    where <span>developers</span>,<span> creators</span>, and
                    <span>players</span> can thrive mutually in
                    a world of Blockchain gaming!
                </div>
            </div>
        </div>
    </div>
    <div class="interoparable-steam-web-main-section">
        <div class="interoparable-section">
            <div class="container">
                <div class="row my_row">
                    <div class="col l4 m12 s12 my_row">
                        <div class="interoparable-image">
                            <img src="images/interopole.png" />
                        </div>
                    </div>
                    <div class="col l8 m12 s12 my_row">
                        <div class="interoparable-content-section left-align">
                            <div class="brown-black-btn">
                                Doss Games for Developers
                            </div>
                            <div class="interoperable-text">
                                Interoperable game development infrastructure
                            </div>
                            <div class="doss-desc">
                                Build and launch your own Blockchain games with our powerful SDKs and plugins, turn them
                                into engaging and competitive experiences for users, and collaborate with a community of
                                designers, artists, and developers - while boosting your revenue!
                            </div>
                            <div class="doss-btn-section">
                                <a href="developers.php" class="doss-btn">
                                    Build with Doss
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="steam-web-section">
            <div class="container">
                <div class="row my_row">
                    <div class="col l7 m12 s12 my_row">
                        <div class="interoparable-content-section left-align">
                            <div class="brown-btn">
                                Doss Games for Players
                            </div>
                            <div class="interoperable-text">
                                Steam for Web3 mobile games
                            </div>
                            <div class="doss-desc">
                                Explore, play, and own unlimited blockchain games built by the game development
                                community!
                            </div>
                            <div class="doss-btn-section">
                                <a href="players.php" class="doss-btn">
                                    Play with Doss
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class="col l5 m12 s12 my_row">
                        <div class="interoparable-image">
                            <img src="images/steam-web-image.png" />
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="blockchain-section">
        <div class="container-fluid">
            <div class="row my_row">
                <div class="interoperable-text">
                    Driven for and by Blockchain Gaming Aficionados
                </div>
                <div class="doss-desc">
                    Dive head-first into the world of Blockchain Gaming!
                </div>
                <div class="blockchain-main-grid">
                    <div class="blockchain-grid">
                        Operate in a truly decentralized gaming ecosystem
                    </div>
                    <div class="blockchain-grid">
                        Blockchain ensures user and game item safety
                    </div>
                    <div class="blockchain-grid">
                        Developers have control over their products and the Doss economy
                    </div>
                    <div class="blockchain-grid">
                        All earnings of the game go directly to the developers
                    </div>
                    <div class="blockchain-grid">
                        Be a part of a community of designers, developers, business experts, and Blockchain Gaming
                        enthusiasts alike!
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="roadmap-section">
        <div class="container-fluid">
            <div class="doss-heading">
                Our Roadmap
            </div>
            <div class="border-white"></div>
            <div class="row my_row">

                <div class="col l4 m12 s12 my_row">
                    <div class="roadmap-grid">
                        <div class="year-heading">
                            H1 2022
                        </div>
                        <div class="pink-bullet"></div>
                        <div class="roadmap-desc">
                            <ul>
                                <li class="rm-completed">Player App: 8 games live</li>
                                <li class="rm-completed">Doss game wallet unity plugin</li>
                                <li class="rm-inprogress">Staking as a platform</li>
                                <li class="rm-inprogress">Decentralised gaming studio</li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col l4 m12 s12 my_row">
                    <div class="roadmap-grid">
                        <div class="year-heading">
                            H2 2022
                        </div>
                        <div class="pink-bullet"></div>
                        <div class="roadmap-desc">
                            <ul>
                                <li>Onboard 100K players</li>
                                <li>Onboard 500 game creators</li>
                                <li>Tokenomics as a platform</li>
                                <li>Proof of playtime</li>
                                <li>Moderate to earn</li>
                                <li>Steam 3.0</li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col l4 m12 s12 my_row">
                    <div class="roadmap-grid">
                        <div class="year-heading">
                            H1 2023
                        </div>
                        <div class="pink-bullet"></div>
                        <div class="roadmap-desc">
                            <ul>
                                <li>Interoperable backend/ fork and build</li>
                                <li>Interoperable NFT launchpad</li>
                                <li>Layer 1 protocol</li>
                                <li>Onboard 1M players and 10K game creators </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="cdp-section">
        <div class="container-fluid">
            <div class="row my_row">
                <div class="interoperable-text">
                    Collaborate, Develop, and Publish. All in one place.
                </div>
                <div class="doss-desc">
                    We have an exciting lineup of blockchain suites for developers:
                </div>
                <div class="cdp-main-grid">
                    <div class="cdp-grid">
                        <div class="cdp-image">
                            <img src="images/cdp-crypto-image.png" />
                        </div>
                        <div class="cdp-content">
                            <div class="cdp-heading">Gaming Crypto Wallet</div>
                            <div class="cdp-desc">Crypto wallet plugin for easy blockchain integration</div>
                        </div>
                    </div>
                    <div class="cdp-grid">
                        <div class="cdp-image">
                            <img src="images/cdp-blockchain-image.png" />
                        </div>
                        <div class="cdp-content">
                            <div class="cdp-heading">Blockchain Tournaments</div>
                            <div class="cdp-desc">Run tournaments in a decentralized environment and start earning a
                                passive income</div>
                        </div>
                    </div>
                    <div class="cdp-grid">
                        <div class="cdp-image">
                            <img src="images/cdp-decentralised-image.png" />
                        </div>
                        <div class="cdp-content">
                            <div class="cdp-heading">Decentralized
                                Autonomous
                                Gaming Studios
                            </div>
                            <div class="cdp-desc">Collaborate with other creators and
                                developers to build blockchain games and distribute the ownership and revenue fairly.
                            </div>
                        </div>
                    </div>
                    <div class="cdp-grid">
                        <div class="cdp-image">
                            <img src="images/cdp-steam-image.png" />
                        </div>
                        <div class="cdp-content">
                            <div class="cdp-heading">Steam3</div>
                            <div class="cdp-desc">Publish your games to the world. Explore and play top blockchain
                                games.</div>
                        </div>
                    </div>
                    <div class="cdp-grid">
                        <div class="cdp-image">
                            <img src="images/cdp-fork-image.png" />
                        </div>
                        <div class="cdp-content">
                            <div class="cdp-heading">Fork & Build</div>
                            <div class="cdp-desc">Fork the games to build mods over them. Everyone gets their fair share
                                of ownership and revenue
                            </div>
                        </div>
                    </div>
                    <div class="cdp-grid">
                        <div class="cdp-image">
                            <img src="images/cdp-interperble-image.png" />
                        </div>
                        <div class="cdp-content">
                            <div class="cdp-heading">Interoperable
                                NFT launchpad
                            </div>
                            <div class="cdp-desc">Build your games around the top NFT projects and get
                                all the distributions of NFTs
                            </div>
                        </div>
                    </div>
                    <div class="cdp-grid">
                        <div class="cdp-image">
                            <img src="images/cdp-tokenomix-image.png" />
                        </div>
                        <div class="cdp-content">
                            <div class="cdp-heading">Tokenomics-as
                                -a-Platform
                            </div>
                            <div class="cdp-desc">Build your in-game tokenomics with ease and open your
                                economy to the world
                            </div>
                        </div>
                    </div>
                    <div class="cdp-grid">
                        <div class="cdp-image">
                            <img src="images/cdp-protocol-image.png" />
                        </div>
                        <div class="cdp-content">
                            <div class="cdp-heading">L1 Protocol</div>
                            <div class="cdp-desc">Trustless creation, real-time playing, and ownership with L1 protocol
                            </div>
                        </div>
                    </div>
                    <div class="cdp-grid">
                        <div class="cdp-image">
                            <img src="images/cdp-proof-image.png" />
                        </div>
                        <div class="cdp-content">
                            <div class="cdp-heading">Proof-of-Playtime</div>
                            <div class="cdp-desc">Fraud prevention by proof-of-playtime. You unlock your tokens as you
                                move forward in the ecosystem.</div>
                        </div>
                    </div>
                    <div class="cdp-grid">
                        <div class="cdp-image">
                            <img src="images/cdp-reputation-image.png" />
                        </div>
                        <div class="cdp-content">
                            <div class="cdp-heading">Reputation NFTs</div>
                            <div class="cdp-desc">Single-chain ID to determine your reputation in the ecosystem</div>
                        </div>
                    </div>
                    <div class="cdp-grid">
                        <div class="cdp-image">
                            <img src="images/cdp-moderate-image.png" />
                        </div>
                        <div class="cdp-content">
                            <div class="cdp-heading">Moderate to Earn</div>
                            <div class="cdp-desc">Watch and moderate games to have a fair play in the ecosystem and
                                earn!</div>
                        </div>
                    </div>
                    <div class="cdp-grid doss-btn-section">
                        <a href="developers.php" class="doss-btn">
                            Build with Doss
                        </a>
                    </div>
                </div>
            </div>
        </div>

        <div class="form-section">
            <div class="container-fluid">
                <div class="row my_row">
                    <div class="interoperable-text">
                        This is an arcade built for the new internet era.
                    </div>
                    <div class="doss-desc2">
                        We invite you to be a part of it!
                    </div>
                    <div class="join-community-class">
                        Join our Community
                    </div>
                    <div class="community-form-section">
                        <form id="doss-form"
                            onsubmit=" alert('Thank you, we have received your request. Our team will get back to you very soon');return false;">
                            <!-- <div class="frm_message" style="display:none">
                                asfasdf asdfasdf asfasdf
                            </div> -->
                            <div class="row my_row">
                                <div class="input-field col l3 m6 s12">
                                    <input placeholder="Name" id="name" type="text" required class="validate">
                                    <span class="nameerr" style="color: red; font-weight: 600;"></span>
                                </div>
                                <div class="input-field col l3 m6 s12">
                                    <input id="email" type="email" class="validate" required placeholder="Email">
                                    <span class="emailerr" style="color: red; font-weight: 600;"></span>
                                </div>
                                <div class="input-field col l3 m6 s12">
                                    I want to join Doss Games:
                                </div>
                                <div class="input-field col l3 m6 s12">
                                    <div class="custom-select margin-15 ">
                                        <select id="category" name="category">
                                            <option value="">Select</option>
                                            <option value="As a Developer">As a Developer</option>
                                            <option value="As a Designer">As a Designer</option>
                                            <option value="As a Gamer">As a Gamer</option>
                                            <option value="As an employee">As an employee</option>
                                        </select>
                                        <span class="category" style="color: red; font-weight: 600;"></span>
                                    </div>
                                </div>
                            </div>
                            <div class="center">
                                <button id="btn-submit" class="btn btn-success doss-btn" onclick="readFormData()">
                                    Submit
                                </button>
                                <!-- <a href="#" class="doss-btn">
                                    Submit
                                </a> -->
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <?php include_once('footer.php') ?>
    </div>
</div>
<script>
/* Form Submistion */

var readFormData = () => {
    var name = $("#name").val();
    var category = $("#category").val();
    var email = $("#email").val();
    var errors = 0;
    /* Form Validation */
    if (name == '') {
        $(".nameerr").html("Please Fill the Name*");
        errors++;
    } else {
        $(".nameerr").html("");
    }

    if (email == '') {
        $(".emailerr").html("Please Fill the Email Id*");
        errors++;
    } else {
        $(".emailerr").html("");
    }
    if (category == '') {
        $(".category").html("Please select the category");
        errors++;
    } else {
        $(".category").html("");
    }

    if (errors == 0) {

        data = {
            name: $("#name").val(),
            category: $("#category").val(),
            email: $("#email").val()
        }
        $.ajax({
            url: 'data.php',
            method: 'POST',
            data: data,
            // dataType:'JSON',
            success: (res) => {
                name = $("#name").val("");
                category = $("#category").val("");
                email = $("#email").val("");
                // $(".frm_message").delay(5000).fadeOut(1000);

                console.log("success");

                console.log(res);
            },
            error: (err) => {
                console.log(err);
                console.log("err");
            }
        })
    }
}
</script>